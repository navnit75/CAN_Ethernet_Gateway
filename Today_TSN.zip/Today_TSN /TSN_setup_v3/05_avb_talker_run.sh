# On talker host 
sudo speaker-test -p 25000 -F S16_BE -c 2 -r 48000 -D aaf0
# sudo aplay -F 12500 -D converter1 piano2.wav


