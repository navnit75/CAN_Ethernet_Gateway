ip link delete enp3s0.1
ip link delete enp3s0.2
ip link delete enp3s0.3
ip link delete enp3s0.4
ip link delete enp3s0.5
ip link delete enp3s0.6
ip link delete enp3s0.7
ip link delete enp3s0.8