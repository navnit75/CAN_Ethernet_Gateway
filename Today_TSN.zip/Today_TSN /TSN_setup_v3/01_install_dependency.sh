sudo apt install build-essential git meson flex bison libglib2.0-0 \
        libcmocka-dev autoconf libtool autopoint libncurses-dev \
        libpulse-dev
