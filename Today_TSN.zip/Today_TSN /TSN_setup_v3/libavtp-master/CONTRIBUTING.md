Copyright (C) 2019 Intel Corporation.  All rights reserved.

All contributions to this project are contributed under the terms of the BSD-3-Clause licence.  

By making a contribution to this project, you certify that:

(a) The contribution was created in whole or in part by you, and you
    have the right to submit it under the open source license
    indicated in the file; or

(b) The contribution is based upon previous work that, to the best
    of your knowledge, is covered under an appropriate open source
    license and you have the right under that license to submit that
    work with modifications, whether created in whole or in part
    by you, under the same open source license (unless you am
    permitted to submit under a different license), as indicated
    in the file; or

(c) The contribution was provided directly to you by some other
    person who certified (a), (b) or (c) and you have not modified
    it.

(d) You understand and agree that this project and the contribution
    are public and that a record of the contribution (including all
    personal information you submit with it, including your sign-off) is
    maintained indefinitely and may be redistributed consistent with
    this project or the open source license(s) involved.
