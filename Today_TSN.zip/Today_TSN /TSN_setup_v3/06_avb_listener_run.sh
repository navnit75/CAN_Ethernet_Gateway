sudo arecord -F 25000 -t raw -f S16_BE -c 2 -r 48000 -D aaf0 | \
        aplay -F 25000 -t raw -f S16_BE -c 2 -r 48000 -D converter0
