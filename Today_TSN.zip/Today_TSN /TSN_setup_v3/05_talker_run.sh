cd talker-listener-tsn/build
gnome-terminal -t "TSN-TALKER" --command="bash -c 'sudo sh tsn-talker-run.sh; $SHELL'"
