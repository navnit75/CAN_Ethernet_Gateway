cd talker-listener-tsn/build
gnome-terminal -t "TSN_LISTENER" --command="bash -c 'sudo sh tsn-listener-run.sh; $SHELL'"
