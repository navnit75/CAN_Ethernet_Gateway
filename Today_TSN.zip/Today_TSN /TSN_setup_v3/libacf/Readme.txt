1. To run the talker and listener application separate bash scripts are created. 
2. You need to edit the commands inside the scripts for specification of destination and source MAC address as well as interfaces
 

3. TSCF: 
   Talker : 
        sh tscf_talker_run.sh
    Listener: 
        sh tscf_listener_run.sh

4. NTSCF: 
    Talker: 
        sh ntscf_talker_run.sh
    Listener: 
        sh ntscf_listener_run.sh

5. If in requirement for separate build command you can use , specified build commands to build talker and listener separately. 

6. TSCF: 
        Talker: 
            cc -I./src -I./include -o tscf_talker src/avtp.c src/avtp_tscf.c src/common.c src/avtp_stream.c src/can.c tscf_talker.c
        Listener: 
            cc -I./src -I./include -o tscf_listener src/avtp.c src/avtp_tscf.c src/common.c src/avtp_stream.c src/can.c tscf_listener.c

7. NTSCF: 
        Talker: 
            cc -I./src -I./include -o ntscf_talker src/avtp.c src/avtp_ntscf.c src/common.c src/avtp_stream.c src/can.c ntscf_talker.c
        Listener: 
            cc -I./src -I./include -o ntscf_listener src/avtp.c src/avtp_ntscf.c src/common.c src/avtp_stream.c src/can.c ntscf_listener.c

8. You can use --help for information regarding arguments: 
    Example: 
        1. cc -I./src -I./include -o tscf_talker src/avtp.c src/avtp_tscf.c src/common.c src/avtp_stream.c src/can.c tscf_talker.c
        2. ./tscf_talker --help 
