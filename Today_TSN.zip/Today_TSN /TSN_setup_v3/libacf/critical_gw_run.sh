# Building tscf_listener
cc -I./src -I./include -o critical_gw src/avtp.c src/avtp_tscf.c src/common.c src/avtp_stream.c src/can.c critical_gw.c

# sudo ./tscf_listener -d <source MAC address> -i <inteface name> -m <max-transmission time> 

# Example: 
sudo ./critical_gw -d 00:e0:4d:0c:66:ed  -i wlx00e04d0c66ed -p 3 -n 20
