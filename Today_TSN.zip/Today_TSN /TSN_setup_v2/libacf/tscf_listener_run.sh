# Building tscf_listener
cc -I./src -I./include -o tscf_listener src/avtp.c src/avtp_tscf.c src/common.c src/avtp_stream.c src/can.c tscf_listener.c

# sudo ./tscf_listener -d <source MAC address> -i <inteface name> -m <max-transmission time> 

# Example: 
sudo ./tscf_listener -d 00:e0:4d:0c:66:ed -i wlx00e04d0c66ed
