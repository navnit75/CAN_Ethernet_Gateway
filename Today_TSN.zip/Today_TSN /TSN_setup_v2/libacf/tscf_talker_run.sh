# Compiling the tscf_talker
cc -I./src -I./include -o tscf_talker src/avtp.c src/avtp_tscf.c src/common.c src/avtp_stream.c src/can.c tscf_talker.c

# ./tscf_talker -d <destination MAC address> -i <interface name> 
sudo ./tscf_talker -d 00:e0:4d:0c:66:ed  -i wlx00e04d0c66ed -p 3 -n 1000
